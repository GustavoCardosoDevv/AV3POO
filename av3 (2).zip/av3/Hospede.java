import java.io.*;
import java.util.ArrayList;

public class Hospede extends Pessoa {
    private String rg;
    private boolean fidelidade;
    private static final String ARQUIVO = "hospedes.txt";

    public Hospede(String cpf, String nome, int idade, String rg, boolean fidelidade) {
        super(cpf, nome, idade);
        this.rg = rg;
        this.fidelidade = fidelidade;
    }

    public String getRg() {
        return rg;
    }

    public void setRg(String rg) {
        this.rg = rg;
    }

    public boolean isFidelidade() {
        return fidelidade;
    }

    public void setFidelidade(boolean fidelidade) {
        this.fidelidade = fidelidade;
    }

    @Override
    public boolean inserir() throws Exception {
        try {
            FileWriter fw = new FileWriter(ARQUIVO, true);
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(this.toString() + "\n");
            bw.close();
            return true;
        } catch (FileNotFoundException e) {
            throw new Exception("Arquivo não encontrado: " + e.getMessage());
        }
    }

    @Override
    public boolean editar() throws Exception {
        ArrayList<Hospede> hospedes = (ArrayList<Hospede>) listar();
        for (int i = 0; i < hospedes.size(); i++) {
            if (hospedes.get(i).getCpf().equals(this.cpf)) {
                hospedes.set(i, this);
                FileWriter fw = new FileWriter(ARQUIVO);
                BufferedWriter bw = new BufferedWriter(fw);
                for (Hospede h : hospedes) {
                    bw.write(h.toString() + "\n");
                }
                bw.close();
                return true;
            }
        }
        return false;
    }

    @Override
    public ArrayList<Hospede> listar() throws Exception {
        ArrayList<Hospede> hospedes = new ArrayList<>();
        try {
            FileReader fr = new FileReader(ARQUIVO);
            BufferedReader br = new BufferedReader(fr);
            String linha;
            while ((linha = br.readLine()) != null) {
                String[] dados = linha.split(";");
                Hospede h = new Hospede(dados[0], dados[1], Integer.parseInt(dados[2]), dados[3], Boolean.parseBoolean(dados[4]));
                hospedes.add(h);
            }
            br.close();
        } catch (FileNotFoundException e) {
            throw new Exception("Arquivo não encontrado: " + e.getMessage());
        }
        return hospedes;
    }

    @Override
    public Hospede consultar(String cpf) throws Exception {
        ArrayList<Hospede> hospedes = (ArrayList<Hospede>) listar();
        for (Hospede h : hospedes) {
            if (h.getCpf().equals(cpf)) {
                return h;
            }
        }
        return null;
    }

    @Override
    public void mostrar() {
        System.out.println("CPF: " + cpf);
        System.out.println("Nome: " + nome);
        System.out.println("Idade: " + idade);
        System.out.println("RG: " + rg);
        System.out.println("Fidelidade: " + fidelidade);
    }

    @Override
    public String toString() {
        return super.toString() + ";" + rg + ";" + fidelidade;
    }
} 