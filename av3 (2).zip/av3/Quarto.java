import java.io.*;
import java.util.ArrayList;

public class Quarto {
    private int idQuarto;
    private String descQuarto;
    private static final String ARQUIVO = "quartos.txt";

    public Quarto(int idQuarto, String descQuarto) {
        this.idQuarto = idQuarto;
        this.descQuarto = descQuarto;
    }

    public int getIdQuarto() {
        return idQuarto;
    }

    public void setIdQuarto(int idQuarto) {
        this.idQuarto = idQuarto;
    }

    public String getDescQuarto() {
        return descQuarto;
    }

    public void setDescQuarto(String descQuarto) {
        this.descQuarto = descQuarto;
    }

    public boolean inserir() throws Exception {
        try {
            FileWriter fw = new FileWriter(ARQUIVO, true);
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(this.toString() + "\n");
            bw.close();
            return true;
        } catch (FileNotFoundException e) {
            throw new Exception("Arquivo não encontrado: " + e.getMessage());
        }
    }

    public boolean editar() throws Exception {
        ArrayList<Quarto> quartos = listar();
        for (int i = 0; i < quartos.size(); i++) {
            if (quartos.get(i).getIdQuarto() == this.idQuarto) {
                quartos.set(i, this);
                FileWriter fw = new FileWriter(ARQUIVO);
                BufferedWriter bw = new BufferedWriter(fw);
                for (Quarto q : quartos) {
                    bw.write(q.toString() + "\n");
                }
                bw.close();
                return true;
            }
        }
        return false;
    }

    public ArrayList<Quarto> listar() throws Exception {
        ArrayList<Quarto> quartos = new ArrayList<>();
        try {
            FileReader fr = new FileReader(ARQUIVO);
            BufferedReader br = new BufferedReader(fr);
            String linha;
            while ((linha = br.readLine()) != null) {
                String[] dados = linha.split(";");
                Quarto q = new Quarto(Integer.parseInt(dados[0]), dados[1]);
                quartos.add(q);
            }
            br.close();
        } catch (FileNotFoundException e) {
            throw new Exception("Arquivo não encontrado: " + e.getMessage());
        }
        return quartos;
    }

    public Quarto consultar(int id) throws Exception {
        ArrayList<Quarto> quartos = listar();
        for (Quarto q : quartos) {
            if (q.getIdQuarto() == id) {
                return q;
            }
        }
        return null;
    }

    public void mostrar() {
        System.out.println("ID do Quarto: " + idQuarto);
        System.out.println("Descrição: " + descQuarto);
    }

    @Override
    public String toString() {
        return idQuarto + ";" + descQuarto;
    }
} 