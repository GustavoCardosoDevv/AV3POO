import java.io.*;
import java.util.ArrayList;

public class Consumo {
    private int idConsumo;
    private Produto produto;
    private Reserva reserva;
    private double quantidade;
    private static final String ARQUIVO = "consumos.txt";

    public Consumo(int idConsumo, Produto produto, Reserva reserva, double quantidade) {
        this.idConsumo = idConsumo;
        this.produto = produto;
        this.reserva = reserva;
        this.quantidade = quantidade;
    }

    public int getIdConsumo() {
        return idConsumo;
    }

    public void setIdConsumo(int idConsumo) {
        this.idConsumo = idConsumo;
    }

    public Produto getProduto() {
        return produto;
    }

    public void setProduto(Produto produto) {
        this.produto = produto;
    }

    public Reserva getReserva() {
        return reserva;
    }

    public void setReserva(Reserva reserva) {
        this.reserva = reserva;
    }

    public double getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(double quantidade) {
        this.quantidade = quantidade;
    }

    public boolean inserir() throws Exception {
        try {
            FileWriter fw = new FileWriter(ARQUIVO, true);
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(this.toString() + "\n");
            bw.close();
            return true;
        } catch (FileNotFoundException e) {
            throw new Exception("Arquivo não encontrado: " + e.getMessage());
        }
    }

    public boolean editar() throws Exception {
        ArrayList<Consumo> consumos = listar();
        for (int i = 0; i < consumos.size(); i++) {
            if (consumos.get(i).getIdConsumo() == this.idConsumo) {
                consumos.set(i, this);
                FileWriter fw = new FileWriter(ARQUIVO);
                BufferedWriter bw = new BufferedWriter(fw);
                for (Consumo c : consumos) {
                    bw.write(c.toString() + "\n");
                }
                bw.close();
                return true;
            }
        }
        return false;
    }

    public ArrayList<Consumo> listar() throws Exception {
        ArrayList<Consumo> consumos = new ArrayList<>();
        try {
            FileReader fr = new FileReader(ARQUIVO);
            BufferedReader br = new BufferedReader(fr);
            String linha;
            while ((linha = br.readLine()) != null) {
                String[] dados = linha.split(";");
                System.out.println("Debug - Linha lida: " + linha);
                System.out.println("Debug - Número de campos: " + dados.length);
                if (dados.length >= 13) {
                    try {
                        Produto p = new Produto(Integer.parseInt(dados[1]), dados[2], Double.parseDouble(dados[3]));
                        Quarto q = new Quarto(Integer.parseInt(dados[5]), dados[6]);
                        Hospede h = new Hospede(dados[7], dados[8], Integer.parseInt(dados[9]), dados[10], Boolean.parseBoolean(dados[11]));
                        Reserva r = new Reserva(Integer.parseInt(dados[4]), 0, "", "", false, false, q, h);
                        Consumo c = new Consumo(Integer.parseInt(dados[0]), p, r, Double.parseDouble(dados[12]));
                        consumos.add(c);
                    } catch (NumberFormatException e) {
                        System.out.println("Erro ao converter número: " + e.getMessage());
                    }
                } else {
                    System.out.println("Linha ignorada - formato inválido: " + linha);
                }
            }
            br.close();
        } catch (FileNotFoundException e) {
            throw new Exception("Arquivo não encontrado: " + e.getMessage());
        }
        return consumos;
    }

    public Consumo consultar(int id) throws Exception {
        ArrayList<Consumo> consumos = listar();
        for (Consumo c : consumos) {
            if (c.getIdConsumo() == id) {
                return c;
            }
        }
        return null;
    }

    public void mostrar() {
        System.out.println("ID do Consumo: " + idConsumo);
        System.out.println("Produto: " + produto.getDescProduto());
        System.out.println("Valor Unitário: R$ " + produto.getValor());
        System.out.println("Quantidade: " + quantidade);
        System.out.println("Valor Total: R$ " + (produto.getValor() * quantidade));
        System.out.println("Reserva: " + reserva.getIdReserva());
        System.out.println("Hóspede: " + reserva.getHospede().getNome());
    }

    @Override
    public String toString() {
        if (produto == null || reserva == null) {
            return idConsumo + ";;;;;;;";
        }
        return idConsumo + ";" + 
               produto.getIdProduto() + ";" + 
               produto.getDescProduto() + ";" + 
               produto.getValor() + ";" + 
               reserva.getIdReserva() + ";" + 
               reserva.getQuarto().getIdQuarto() + ";" + 
               reserva.getQuarto().getDescQuarto() + ";" + 
               reserva.getHospede().getCpf() + ";" + 
               reserva.getHospede().getNome() + ";" + 
               reserva.getHospede().getIdade() + ";" + 
               reserva.getHospede().getRg() + ";" + 
               reserva.getHospede().isFidelidade() + ";" + 
               quantidade;
    }
} 