import java.io.*;
import java.util.ArrayList;

public class Reserva {
    private int idReserva;
    private double valor;
    private String dataEntrada;
    private String dataSaida;
    private boolean checkin;
    private boolean checkout;
    private Quarto quarto;
    private Hospede hospede;
    private static final String ARQUIVO = "reservas.txt";

    public Reserva(int idReserva, double valor, String dataEntrada, String dataSaida, boolean checkin, boolean checkout, Quarto quarto, Hospede hospede) {
        this.idReserva = idReserva;
        this.valor = valor;
        this.dataEntrada = dataEntrada;
        this.dataSaida = dataSaida;
        this.checkin = checkin;
        this.checkout = checkout;
        this.quarto = quarto;
        this.hospede = hospede;
    }

    public int getIdReserva() {
        return idReserva;
    }

    public void setIdReserva(int idReserva) {
        this.idReserva = idReserva;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public String getDataEntrada() {
        return dataEntrada;
    }

    public void setDataEntrada(String dataEntrada) {
        this.dataEntrada = dataEntrada;
    }

    public String getDataSaida() {
        return dataSaida;
    }

    public void setDataSaida(String dataSaida) {
        this.dataSaida = dataSaida;
    }

    public boolean isCheckin() {
        return checkin;
    }

    public void setCheckin(boolean checkin) {
        this.checkin = checkin;
    }

    public boolean isCheckout() {
        return checkout;
    }

    public void setCheckout(boolean checkout) {
        this.checkout = checkout;
    }

    public Quarto getQuarto() {
        return quarto;
    }

    public void setQuarto(Quarto quarto) {
        this.quarto = quarto;
    }

    public Hospede getHospede() {
        return hospede;
    }

    public void setHospede(Hospede hospede) {
        this.hospede = hospede;
    }

    public boolean inserir() throws Exception {
        try {
            FileWriter fw = new FileWriter(ARQUIVO, true);
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(this.toString() + "\n");
            bw.close();
            return true;
        } catch (FileNotFoundException e) {
            throw new Exception("Arquivo não encontrado: " + e.getMessage());
        }
    }

    public boolean editar() throws Exception {
        ArrayList<Reserva> reservas = listar();
        for (int i = 0; i < reservas.size(); i++) {
            if (reservas.get(i).getIdReserva() == this.idReserva) {
                reservas.set(i, this);
                FileWriter fw = new FileWriter(ARQUIVO);
                BufferedWriter bw = new BufferedWriter(fw);
                for (Reserva r : reservas) {
                    bw.write(r.toString() + "\n");
                }
                bw.close();
                return true;
            }
        }
        return false;
    }

    public ArrayList<Reserva> listar() throws Exception {
        ArrayList<Reserva> reservas = new ArrayList<>();
        try {
            FileReader fr = new FileReader(ARQUIVO);
            BufferedReader br = new BufferedReader(fr);
            String linha;
            while ((linha = br.readLine()) != null) {
                String[] dados = linha.split(";");
                Quarto q = new Quarto(Integer.parseInt(dados[6]), dados[7]);
                Hospede h = new Hospede(dados[8], dados[9], Integer.parseInt(dados[10]), dados[11], Boolean.parseBoolean(dados[12]));
                Reserva r = new Reserva(Integer.parseInt(dados[0]), Double.parseDouble(dados[1]), dados[2], dados[3], Boolean.parseBoolean(dados[4]), Boolean.parseBoolean(dados[5]), q, h);
                reservas.add(r);
            }
            br.close();
        } catch (FileNotFoundException e) {
            throw new Exception("Arquivo não encontrado: " + e.getMessage());
        }
        return reservas;
    }

    public Reserva consultar(int id) throws Exception {
        ArrayList<Reserva> reservas = listar();
        for (Reserva r : reservas) {
            if (r.getIdReserva() == id) {
                return r;
            }
        }
        return null;
    }

    public void mostrar() {
        System.out.println("ID da Reserva: " + idReserva);
        System.out.println("Valor: R$ " + valor);
        System.out.println("Data de Entrada: " + dataEntrada);
        System.out.println("Data de Saída: " + dataSaida);
        System.out.println("Check-in: " + (checkin ? "Realizado" : "Pendente"));
        System.out.println("Check-out: " + (checkout ? "Realizado" : "Pendente"));
        System.out.println("Quarto: " + quarto.getDescQuarto());
        System.out.println("Hóspede: " + hospede.getNome());
    }

    @Override
    public String toString() {
        return idReserva + ";" + valor + ";" + dataEntrada + ";" + dataSaida + ";" + checkin + ";" + checkout + ";" + quarto.getIdQuarto() + ";" + quarto.getDescQuarto() + ";" + hospede.getCpf() + ";" + hospede.getNome() + ";" + hospede.getIdade() + ";" + hospede.getRg() + ";" + hospede.isFidelidade();
    }
} 