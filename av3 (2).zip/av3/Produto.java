import java.io.*;
import java.util.ArrayList;

public class Produto {
    private int idProduto;
    private String descProduto;
    private double valor;
    private static final String ARQUIVO = "produtos.txt";

    public Produto(int idProduto, String descProduto, double valor) {
        this.idProduto = idProduto;
        this.descProduto = descProduto;
        this.valor = valor;
    }

    public int getIdProduto() {
        return idProduto;
    }

    public void setIdProduto(int idProduto) {
        this.idProduto = idProduto;
    }

    public String getDescProduto() {
        return descProduto;
    }

    public void setDescProduto(String descProduto) {
        this.descProduto = descProduto;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public boolean inserir() throws Exception {
        try {
            FileWriter fw = new FileWriter(ARQUIVO, true);
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(this.toString() + "\n");
            bw.close();
            return true;
        } catch (FileNotFoundException e) {
            throw new Exception("Arquivo não encontrado: " + e.getMessage());
        }
    }

    public boolean editar() throws Exception {
        ArrayList<Produto> produtos = listar();
        for (int i = 0; i < produtos.size(); i++) {
            if (produtos.get(i).getIdProduto() == this.idProduto) {
                produtos.set(i, this);
                FileWriter fw = new FileWriter(ARQUIVO);
                BufferedWriter bw = new BufferedWriter(fw);
                for (Produto p : produtos) {
                    bw.write(p.toString() + "\n");
                }
                bw.close();
                return true;
            }
        }
        return false;
    }

    public ArrayList<Produto> listar() throws Exception {
        ArrayList<Produto> produtos = new ArrayList<>();
        try {
            FileReader fr = new FileReader(ARQUIVO);
            BufferedReader br = new BufferedReader(fr);
            String linha;
            while ((linha = br.readLine()) != null) {
                String[] dados = linha.split(";");
                Produto p = new Produto(Integer.parseInt(dados[0]), dados[1], Double.parseDouble(dados[2]));
                produtos.add(p);
            }
            br.close();
        } catch (FileNotFoundException e) {
            throw new Exception("Arquivo não encontrado: " + e.getMessage());
        }
        return produtos;
    }

    public Produto consultar(int id) throws Exception {
        ArrayList<Produto> produtos = listar();
        for (Produto p : produtos) {
            if (p.getIdProduto() == id) {
                return p;
            }
        }
        return null;
    }

    public void mostrar() {
        System.out.println("ID do Produto: " + idProduto);
        System.out.println("Descrição: " + descProduto);
        System.out.println("Valor: R$ " + valor);
    }

    @Override
    public String toString() {
        return idProduto + ";" + descProduto + ";" + valor;
    }
} 