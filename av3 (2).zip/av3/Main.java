import java.util.Scanner;
import java.util.ArrayList;

public class Main {
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        int opcao;
        do {
            System.out.println("\n=== MENU PRINCIPAL ===");
            System.out.println("1 - Gerenciar Funcionários");
            System.out.println("2 - Gerenciar Hóspedes");
            System.out.println("3 - Gerenciar Quartos");
            System.out.println("4 - Gerenciar Produtos");
            System.out.println("5 - Gerenciar Reservas");
            System.out.println("6 - Gerenciar Consumos");
            System.out.println("0 - Sair");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine(); // Limpar o buffer

            switch (opcao) {
                case 1:
                    menuFuncionario();
                    break;
                case 2:
                    menuHospede();
                    break;
                case 3:
                    menuQuarto();
                    break;
                case 4:
                    menuProduto();
                    break;
                case 5:
                    menuReserva();
                    break;
                case 6:
                    menuConsumo();
                    break;
                case 0:
                    System.out.println("Saindo do sistema...");
                    break;
                default:
                    System.out.println("Opção inválida!");
            }
        } while (opcao != 0);
    }

    private static void menuFuncionario() {
        int opcao;
        do {
            System.out.println("\n=== MENU FUNCIONÁRIO ===");
            System.out.println("1 - Inserir");
            System.out.println("2 - Editar");
            System.out.println("3 - Listar");
            System.out.println("4 - Consultar");
            System.out.println("0 - Voltar");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine(); // Limpar o buffer

            try {
                switch (opcao) {
                    case 1:
                        System.out.print("CPF: ");
                        String cpf = scanner.nextLine();
                        System.out.print("Nome: ");
                        String nome = scanner.nextLine();
                        System.out.print("Idade: ");
                        int idade = scanner.nextInt();
                        scanner.nextLine(); // Limpar o buffer
                        System.out.print("Função: ");
                        String funcao = scanner.nextLine();
                        
                        Funcionario f = new Funcionario(cpf, nome, idade, funcao);
                        if (f.inserir()) {
                            System.out.println("Funcionário inserido com sucesso!");
                        }
                        break;
                    case 2:
                        System.out.print("CPF do funcionário a editar: ");
                        String cpfEdit = scanner.nextLine();
                        Funcionario fEdit = new Funcionario(cpfEdit, "", 0, "");
                        fEdit = (Funcionario) fEdit.consultar(cpfEdit);
                        if (fEdit != null) {
                            System.out.print("Novo nome: ");
                            fEdit.setNome(scanner.nextLine());
                            System.out.print("Nova idade: ");
                            fEdit.setIdade(scanner.nextInt());
                            scanner.nextLine(); // Limpar o buffer
                            System.out.print("Nova função: ");
                            fEdit.setFuncao(scanner.nextLine());
                            
                            if (fEdit.editar()) {
                                System.out.println("Funcionário editado com sucesso!");
                            }
                        } else {
                            System.out.println("Funcionário não encontrado!");
                        }
                        break;
                    case 3:
                        ArrayList<Funcionario> funcionarios = (ArrayList<Funcionario>) new Funcionario("", "", 0, "").listar();
                        for (Funcionario func : funcionarios) {
                            func.mostrar();
                        }
                        break;
                    case 4:
                        System.out.print("CPF do funcionário: ");
                        String cpfCons = scanner.nextLine();
                        Funcionario fCons = new Funcionario(cpfCons, "", 0, "");
                        fCons = (Funcionario) fCons.consultar(cpfCons);
                        if (fCons != null) {
                            fCons.mostrar();
                        } else {
                            System.out.println("Funcionário não encontrado!");
                        }
                        break;
                    case 0:
                        break;
                    default:
                        System.out.println("Opção inválida!");
                }
            } catch (Exception e) {
                System.out.println("Erro: " + e.getMessage());
            }
        } while (opcao != 0);
    }

    private static void menuHospede() {
        int opcao;
        do {
            System.out.println("\n=== MENU HÓSPEDE ===");
            System.out.println("1 - Inserir");
            System.out.println("2 - Editar");
            System.out.println("3 - Listar");
            System.out.println("4 - Consultar");
            System.out.println("0 - Voltar");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine(); // Limpar o buffer

            try {
                switch (opcao) {
                    case 1:
                        System.out.print("CPF: ");
                        String cpf = scanner.nextLine();
                        System.out.print("Nome: ");
                        String nome = scanner.nextLine();
                        System.out.print("Idade: ");
                        int idade = scanner.nextInt();
                        scanner.nextLine(); // Limpar o buffer
                        System.out.print("RG: ");
                        String rg = scanner.nextLine();
                        System.out.print("Fidelidade (true/false): ");
                        boolean fidelidade = scanner.nextBoolean();
                        scanner.nextLine(); // Limpar o buffer
                        
                        Hospede h = new Hospede(cpf, nome, idade, rg, fidelidade);
                        if (h.inserir()) {
                            System.out.println("Hóspede inserido com sucesso!");
                        }
                        break;
                    case 2:
                        System.out.print("CPF do hóspede a editar: ");
                        String cpfEdit = scanner.nextLine();
                        Hospede hEdit = new Hospede(cpfEdit, "", 0, "", false);
                        hEdit = (Hospede) hEdit.consultar(cpfEdit);
                        if (hEdit != null) {
                            System.out.print("Novo nome: ");
                            hEdit.setNome(scanner.nextLine());
                            System.out.print("Nova idade: ");
                            hEdit.setIdade(scanner.nextInt());
                            scanner.nextLine(); // Limpar o buffer
                            System.out.print("Novo RG: ");
                            hEdit.setRg(scanner.nextLine());
                            System.out.print("Nova fidelidade (true/false): ");
                            hEdit.setFidelidade(scanner.nextBoolean());
                            scanner.nextLine(); // Limpar o buffer
                            
                            if (hEdit.editar()) {
                                System.out.println("Hóspede editado com sucesso!");
                            }
                        } else {
                            System.out.println("Hóspede não encontrado!");
                        }
                        break;
                    case 3:
                        ArrayList<Hospede> hospedes = (ArrayList<Hospede>) new Hospede("", "", 0, "", false).listar();
                        for (Hospede hosp : hospedes) {
                            hosp.mostrar();
                        }
                        break;
                    case 4:
                        System.out.print("CPF do hóspede: ");
                        String cpfCons = scanner.nextLine();
                        Hospede hCons = new Hospede(cpfCons, "", 0, "", false);
                        hCons = (Hospede) hCons.consultar(cpfCons);
                        if (hCons != null) {
                            hCons.mostrar();
                        } else {
                            System.out.println("Hóspede não encontrado!");
                        }
                        break;
                    case 0:
                        break;
                    default:
                        System.out.println("Opção inválida!");
                }
            } catch (Exception e) {
                System.out.println("Erro: " + e.getMessage());
            }
        } while (opcao != 0);
    }

    private static void menuQuarto() {
        int opcao;
        do {
            System.out.println("\n=== MENU QUARTO ===");
            System.out.println("1 - Inserir");
            System.out.println("2 - Editar");
            System.out.println("3 - Listar");
            System.out.println("4 - Consultar");
            System.out.println("0 - Voltar");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine(); // Limpar o buffer

            try {
                switch (opcao) {
                    case 1:
                        System.out.print("ID do quarto: ");
                        int id = scanner.nextInt();
                        scanner.nextLine(); // Limpar o buffer
                        System.out.print("Descrição: ");
                        String desc = scanner.nextLine();
                        
                        Quarto q = new Quarto(id, desc);
                        if (q.inserir()) {
                            System.out.println("Quarto inserido com sucesso!");
                        }
                        break;
                    case 2:
                        System.out.print("ID do quarto a editar: ");
                        int idEdit = scanner.nextInt();
                        scanner.nextLine(); // Limpar o buffer
                        Quarto qEdit = new Quarto(idEdit, "");
                        qEdit = qEdit.consultar(idEdit);
                        if (qEdit != null) {
                            System.out.print("Nova descrição: ");
                            qEdit.setDescQuarto(scanner.nextLine());
                            
                            if (qEdit.editar()) {
                                System.out.println("Quarto editado com sucesso!");
                            }
                        } else {
                            System.out.println("Quarto não encontrado!");
                        }
                        break;
                    case 3:
                        ArrayList<Quarto> quartos = new Quarto(0, "").listar();
                        for (Quarto qua : quartos) {
                            qua.mostrar();
                        }
                        break;
                    case 4:
                        System.out.print("ID do quarto: ");
                        int idCons = scanner.nextInt();
                        scanner.nextLine(); // Limpar o buffer
                        Quarto qCons = new Quarto(idCons, "");
                        qCons = qCons.consultar(idCons);
                        if (qCons != null) {
                            qCons.mostrar();
                        } else {
                            System.out.println("Quarto não encontrado!");
                        }
                        break;
                    case 0:
                        break;
                    default:
                        System.out.println("Opção inválida!");
                }
            } catch (Exception e) {
                System.out.println("Erro: " + e.getMessage());
            }
        } while (opcao != 0);
    }

    private static void menuProduto() {
        int opcao;
        do {
            System.out.println("\n=== MENU PRODUTO ===");
            System.out.println("1 - Inserir");
            System.out.println("2 - Editar");
            System.out.println("3 - Listar");
            System.out.println("4 - Consultar");
            System.out.println("0 - Voltar");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine(); // Limpar o buffer

            try {
                switch (opcao) {
                    case 1:
                        System.out.print("ID do produto: ");
                        int id = scanner.nextInt();
                        scanner.nextLine(); // Limpar o buffer
                        System.out.print("Descrição: ");
                        String desc = scanner.nextLine();
                        System.out.print("Valor: ");
                        double valor = scanner.nextDouble();
                        scanner.nextLine(); // Limpar o buffer
                        
                        Produto p = new Produto(id, desc, valor);
                        if (p.inserir()) {
                            System.out.println("Produto inserido com sucesso!");
                        }
                        break;
                    case 2:
                        System.out.print("ID do produto a editar: ");
                        int idEdit = scanner.nextInt();
                        scanner.nextLine(); // Limpar o buffer
                        Produto pEdit = new Produto(idEdit, "", 0.0);
                        pEdit = pEdit.consultar(idEdit);
                        if (pEdit != null) {
                            System.out.print("Nova descrição: ");
                            pEdit.setDescProduto(scanner.nextLine());
                            System.out.print("Novo valor: ");
                            pEdit.setValor(scanner.nextDouble());
                            scanner.nextLine(); // Limpar o buffer
                            
                            if (pEdit.editar()) {
                                System.out.println("Produto editado com sucesso!");
                            }
                        } else {
                            System.out.println("Produto não encontrado!");
                        }
                        break;
                    case 3:
                        ArrayList<Produto> produtos = new Produto(0, "", 0.0).listar();
                        for (Produto prod : produtos) {
                            prod.mostrar();
                        }
                        break;
                    case 4:
                        System.out.print("ID do produto: ");
                        int idCons = scanner.nextInt();
                        scanner.nextLine(); // Limpar o buffer
                        Produto pCons = new Produto(idCons, "", 0.0);
                        pCons = pCons.consultar(idCons);
                        if (pCons != null) {
                            pCons.mostrar();
                        } else {
                            System.out.println("Produto não encontrado!");
                        }
                        break;
                    case 0:
                        break;
                    default:
                        System.out.println("Opção inválida!");
                }
            } catch (Exception e) {
                System.out.println("Erro: " + e.getMessage());
            }
        } while (opcao != 0);
    }

    private static void menuReserva() {
        int opcao;
        do {
            System.out.println("\n=== MENU RESERVA ===");
            System.out.println("1 - Inserir");
            System.out.println("2 - Editar");
            System.out.println("3 - Listar");
            System.out.println("4 - Consultar");
            System.out.println("0 - Voltar");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine(); // Limpar o buffer

            try {
                switch (opcao) {
                    case 1:
                        System.out.print("ID da reserva: ");
                        int id = scanner.nextInt();
                        scanner.nextLine(); // Limpar o buffer
                        System.out.print("Valor: ");
                        double valor = scanner.nextDouble();
                        scanner.nextLine(); // Limpar o buffer
                        System.out.print("Data de entrada: ");
                        String dataEntrada = scanner.nextLine();
                        System.out.print("Data de saída: ");
                        String dataSaida = scanner.nextLine();
                        System.out.print("Check-in (true/false): ");
                        boolean checkin = scanner.nextBoolean();
                        scanner.nextLine(); // Limpar o buffer
                        System.out.print("Check-out (true/false): ");
                        boolean checkout = scanner.nextBoolean();
                        scanner.nextLine(); // Limpar o buffer
                        
                        System.out.print("ID do quarto: ");
                        int idQuarto = scanner.nextInt();
                        scanner.nextLine(); // Limpar o buffer
                        Quarto q = new Quarto(idQuarto, "");
                        q = q.consultar(idQuarto);
                        if (q == null) {
                            System.out.println("Quarto não encontrado!");
                            break;
                        }
                        
                        System.out.print("CPF do hóspede: ");
                        String cpfHospede = scanner.nextLine();
                        Hospede h = new Hospede(cpfHospede, "", 0, "", false);
                        h = (Hospede) h.consultar(cpfHospede);
                        if (h == null) {
                            System.out.println("Hóspede não encontrado!");
                            break;
                        }
                        
                        Reserva r = new Reserva(id, valor, dataEntrada, dataSaida, checkin, checkout, q, h);
                        if (r.inserir()) {
                            System.out.println("Reserva inserida com sucesso!");
                        }
                        break;
                    case 2:
                        System.out.print("ID da reserva a editar: ");
                        int idEdit = scanner.nextInt();
                        scanner.nextLine(); // Limpar o buffer
                        Reserva rEdit = new Reserva(idEdit, 0.0, "", "", false, false, null, null);
                        rEdit = rEdit.consultar(idEdit);
                        if (rEdit != null) {
                            System.out.print("Novo valor: ");
                            rEdit.setValor(scanner.nextDouble());
                            scanner.nextLine(); // Limpar o buffer
                            System.out.print("Nova data de entrada: ");
                            rEdit.setDataEntrada(scanner.nextLine());
                            System.out.print("Nova data de saída: ");
                            rEdit.setDataSaida(scanner.nextLine());
                            System.out.print("Novo check-in (true/false): ");
                            rEdit.setCheckin(scanner.nextBoolean());
                            scanner.nextLine(); // Limpar o buffer
                            System.out.print("Novo check-out (true/false): ");
                            rEdit.setCheckout(scanner.nextBoolean());
                            scanner.nextLine(); // Limpar o buffer
                            
                            if (rEdit.editar()) {
                                System.out.println("Reserva editada com sucesso!");
                            }
                        } else {
                            System.out.println("Reserva não encontrada!");
                        }
                        break;
                    case 3:
                        ArrayList<Reserva> reservas = new Reserva(0, 0.0, "", "", false, false, null, null).listar();
                        for (Reserva res : reservas) {
                            res.mostrar();
                        }
                        break;
                    case 4:
                        System.out.print("ID da reserva: ");
                        int idCons = scanner.nextInt();
                        scanner.nextLine(); // Limpar o buffer
                        Reserva rCons = new Reserva(idCons, 0.0, "", "", false, false, null, null);
                        rCons = rCons.consultar(idCons);
                        if (rCons != null) {
                            rCons.mostrar();
                        } else {
                            System.out.println("Reserva não encontrada!");
                        }
                        break;
                    case 0:
                        break;
                    default:
                        System.out.println("Opção inválida!");
                }
            } catch (Exception e) {
                System.out.println("Erro: " + e.getMessage());
            }
        } while (opcao != 0);
    }

    private static void menuConsumo() {
        int opcao;
        do {
            System.out.println("\n=== MENU CONSUMO ===");
            System.out.println("1 - Inserir");
            System.out.println("2 - Editar");
            System.out.println("3 - Listar");
            System.out.println("4 - Consultar");
            System.out.println("0 - Voltar");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine(); // Limpar o buffer

            try {
                switch (opcao) {
                    case 1:
                        System.out.print("ID do consumo: ");
                        int id = scanner.nextInt();
                        scanner.nextLine(); // Limpar o buffer
                        
                        System.out.print("ID do produto: ");
                        int idProduto = scanner.nextInt();
                        scanner.nextLine(); // Limpar o buffer
                        Produto p = new Produto(idProduto, "", 0.0);
                        p = p.consultar(idProduto);
                        if (p == null) {
                            System.out.println("Produto não encontrado!");
                            break;
                        }
                        
                        System.out.print("ID da reserva: ");
                        int idReserva = scanner.nextInt();
                        scanner.nextLine(); // Limpar o buffer
                        Reserva r = new Reserva(idReserva, 0.0, "", "", false, false, null, null);
                        r = r.consultar(idReserva);
                        if (r == null) {
                            System.out.println("Reserva não encontrada!");
                            break;
                        }
                        
                        System.out.print("Quantidade: ");
                        double quantidade = scanner.nextDouble();
                        scanner.nextLine(); // Limpar o buffer
                        
                        Consumo c = new Consumo(id, p, r, quantidade);
                        if (c.inserir()) {
                            System.out.println("Consumo inserido com sucesso!");
                        }
                        break;
                    case 2:
                        System.out.print("ID do consumo a editar: ");
                        int idEdit = scanner.nextInt();
                        scanner.nextLine(); // Limpar o buffer
                        Consumo cEdit = new Consumo(idEdit, null, null, 0.0);
                        cEdit = cEdit.consultar(idEdit);
                        if (cEdit != null) {
                            System.out.print("Nova quantidade: ");
                            cEdit.setQuantidade(scanner.nextDouble());
                            scanner.nextLine(); // Limpar o buffer
                            
                            if (cEdit.editar()) {
                                System.out.println("Consumo editado com sucesso!");
                            }
                        } else {
                            System.out.println("Consumo não encontrado!");
                        }
                        break;
                    case 3:
                        ArrayList<Consumo> consumos = new Consumo(0, null, null, 0.0).listar();
                        for (Consumo cons : consumos) {
                            cons.mostrar();
                        }
                        break;
                    case 4:
                        System.out.print("ID do consumo: ");
                        int idCons = scanner.nextInt();
                        scanner.nextLine(); // Limpar o buffer
                        Consumo cCons = new Consumo(idCons, null, null, 0.0);
                        cCons = cCons.consultar(idCons);
                        if (cCons != null) {
                            cCons.mostrar();
                        } else {
                            System.out.println("Consumo não encontrado!");
                        }
                        break;
                    case 0:
                        break;
                    default:
                        System.out.println("Opção inválida!");
                }
            } catch (Exception e) {
                System.out.println("Erro: " + e.getMessage());
            }
        } while (opcao != 0);
    }
} 