import java.io.*;
import java.util.ArrayList;

public class Funcionario extends Pessoa {
    private String funcao;
    private static final String ARQUIVO = "funcionarios.txt";

    public Funcionario(String cpf, String nome, int idade, String funcao) {
        super(cpf, nome, idade);
        this.funcao = funcao;
    }

    public String getFuncao() {
        return funcao;
    }

    public void setFuncao(String funcao) {
        this.funcao = funcao;
    }

    @Override
    public boolean inserir() throws Exception {
        try {
            FileWriter fw = new FileWriter(ARQUIVO, true);
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(this.toString() + "\n");
            bw.close();
            return true;
        } catch (FileNotFoundException e) {
            throw new Exception("Arquivo não encontrado: " + e.getMessage());
        }
    }

    @Override
    public boolean editar() throws Exception {
        ArrayList<Funcionario> funcionarios = (ArrayList<Funcionario>) listar();
        for (int i = 0; i < funcionarios.size(); i++) {
            if (funcionarios.get(i).getCpf().equals(this.cpf)) {
                funcionarios.set(i, this);
                FileWriter fw = new FileWriter(ARQUIVO);
                BufferedWriter bw = new BufferedWriter(fw);
                for (Funcionario f : funcionarios) {
                    bw.write(f.toString() + "\n");
                }
                bw.close();
                return true;
            }
        }
        return false;
    }

    @Override
    public ArrayList<Funcionario> listar() throws Exception {
        ArrayList<Funcionario> funcionarios = new ArrayList<>();
        try {
            FileReader fr = new FileReader(ARQUIVO);
            BufferedReader br = new BufferedReader(fr);
            String linha;
            while ((linha = br.readLine()) != null) {
                String[] dados = linha.split(";");
                Funcionario f = new Funcionario(dados[0], dados[1], Integer.parseInt(dados[2]), dados[3]);
                funcionarios.add(f);
            }
            br.close();
        } catch (FileNotFoundException e) {
            throw new Exception("Arquivo não encontrado: " + e.getMessage());
        }
        return funcionarios;
    }

    @Override
    public Funcionario consultar(String cpf) throws Exception {
        ArrayList<Funcionario> funcionarios = (ArrayList<Funcionario>) listar();
        for (Funcionario f : funcionarios) {
            if (f.getCpf().equals(cpf)) {
                return f;
            }
        }
        return null;
    }

    @Override
    public void mostrar() {
        System.out.println("CPF: " + cpf);
        System.out.println("Nome: " + nome);
        System.out.println("Idade: " + idade);
        System.out.println("Função: " + funcao);
    }

    @Override
    public String toString() {
        return super.toString() + ";" + funcao;
    }
} 